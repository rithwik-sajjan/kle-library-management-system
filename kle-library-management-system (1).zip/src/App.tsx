/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect, FormEvent } from 'react';
import { 
  Search, Book, Library, ChevronRight, 
  Plus, Edit2, Trash2, User, ShieldCheck, 
  ArrowLeft, LayoutDashboard, Database,
  Settings, LogOut, Info, Mail, Archive, Home,
  BookOpen, Languages
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const LOGO_IMAGE = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAlAMBEQACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAABgQFBwMCAQj/xABDEAABAwMCBAQEBAMFBAsAAAABAgMEAAURBiESEzFLElFhwQcUcZEjMkKhFVKxFjOCkqJDssHwJSY0Y3Ojs8LR4fH/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAwQFAgEG/8QANREAAQMCBAMGBAYCAwAAAAAAAQACAwQREiExQQUTUSIyYXGRoYGx4fAUFSNCwdEzUlOC8f/aAAwDAQACEQMRAD8A3GiIoiKIiiIoiKIlXUd8ktOtsQYsmQypRQtyMeEhXlnBwB5jv32oiWYLL9tkqZkw25S3sKVx4KkHYAlW+c9x6etETPpqIh2WZiXFJ5exbGEjJH8o/T9ep+lETRRF9oiKIiiIoiKIiiIoiKIiiIoiKIiiIoiKIq++NSXrc8iEtSHiNinrjvREuwZSGozMd5bjjyQE/B+Y8I79uooirrsxc9SXWLIat0tm229YdbclIDanXAQRwg9vCOvTfzoie9P6vVMe5VyZbiR1IIDslYRwKAHn1zv0zREzNams7vByrjGXzf7vhcB498berB+uKImAEYoivtERREURFERREURFERREURFEXw0RIbxuV3uEiR8k61GZUUstycN8eCdzkgkbDpnv0oiprYq06fXIE8yZEt0lTyIkBxaQe+2P65oie9P6sjXNvkTo7trfQBtMwniG26SCfUf8As0RM7E+K/wAPLfaWVflwvOf6URVuoLFbtQMoaudv+YbQSpHECkg9NjuKJmllz4S2dTi+GfcgyokpjF1Ckpz16pIHTyx0oizC+6C0y6/cbPYtPy7jcY6C8/MSpZSyE7lOM4UrHkd87DfFERRFRX9tT8liLDU5zXASVNH8ie5Pr9utEU+xP2aC+IscSZEh8kqmSWHVAnH8yu3lsKKVkrhm0qzXFfshU6X6U9UrSVA/Y7f73vREz6du7NziAofbdcbOHOEjI+mNj96ImAiK+0RFERREURFERREURFERREURU9/s6LghDzfCiUyskKJPCodCCDkdjt70RKWpNbWLTLXy9xW7Iltt8RhxGubwk7p4tsAHzPTFEWWR/ibYrU/InXF2S9OnuF1bcaPxtshZ/KCrGAn8uwwQOm2aIs50X8SLNp+9z7ZfGZKoj76eZObb/EV4fDy0/pUFeAgnYk0RfoGwfEXT19nswYM1pD7x8Lcj8I7Hw4UrAUe9ET+O9EX2iKIiiL4feomStf3V6QVp2uInatIawf3eIDfHXGPX6VEKlhfhXvLKQ9ZafjN3Nu7wY7LUqUf+kjY8Y6jPY43wO3Srkcg63UFRGJInNcu8fTy0toRLWl6Okghp9Icx9CRmvXyx4cJzCihpGQuuAnW3RWIsZLcZtttG7vAkEAHHUAda8ZIzDhYoaynbKA8qypiqUiiIoiKIiiIoiKIiiIoiKIpCqNT6IsOooKm59vY56STzmkBC89zxYz70RSvYdE6btB47dZILC8klfK41HzIUrJH3oinS9O2uZObnSrelyU0oLS9k8XEMb7HzA+1EUiPbrfFcDzMVlpaUkBaUAFSds++2KIs11v8UrDpx+RbmI0u4z2tlojsZQhXYKWen2oiynS/wAT9S3DW9tuN+mR7da46lIcjNoKW1JUMEqyckeR7URfof8AgLp65SvnptqZeWrfZxaUEjYnhSAnPf7URM8C2W+2IWiDEYitk8S0sNhCSSBvgeYoizXV/wAVLFpyS9bYseXcbghHEWo7WUpWfytqV138xkURIWkPiHqe+68t1zvk6PbLXCcWpURpB5S0qThIUpRJyPNXpREv/FH4maf1BqS3XixRZfPgLLTyXWvDKRw7JST5KB2x3oi0b4c/EPTeoZDMK3Sno8x7PDCkNcB2BPhxlJwB286Iv0ZRF/Ki/onRREURFERREURFERREURFERREURf/Z";

interface BookItem {
  id: number;
  title: string;
  description: string;
  category: string;
  author: string;
  available: boolean;
  imageUrl?: string;
  borrowedBy?: string;
  fullContent?: string;
  translations?: {
    [key in 'HI' | 'KN']?: {
      title?: string;
      description?: string;
      category?: string;
      fullContent?: string;
    }
  };
}

type UserRole = 'guest' | 'student' | 'employee';

const SAMPLE_CONTENT = `Chapter 1: The Foundation of Modern Systems

In the rapidly evolving landscape of digital technology, the architecture of our brains and our systems must adapt to handle ever-increasing complexity. This book explores the fundamental principles that govern these technical environments...

[Digital Archive Content]
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Chapter 2: Scaling Intelligence

As we dive deeper into the core mechanics, we find that the most efficient way to scale is through distributed nodes and decentralized memory clusters. At KLE Tech, we implement these strategies to ensure that knowledge remains high-bandwidth and ultra-accessible...

[End of Preview]`;

const HI_SAMPLE_CONTENT = `अध्याय 1: आधुनिक प्रणालियों की नींव

डिजिटल तकनीक के तेजी से विकसित होते परिदृश्य में, हमारे मस्तिष्क और हमारी प्रणालियों की वास्तुकला को बढ़ती जटिलता को संभालने के लिए अनुकूल होना चाहिए। यह पुस्तक उन मौलिक सिद्धांतों की खोज करती है जो इन तकनीकी वातावरणों को नियंत्रित करते हैं...

[डिजिटल आर्काइव सामग्री]
लोरेम इप्सम डोलर सिट एमेट, कॉनसेक्टेटुर एडिपिसिंग एलीट। सेड डो ईयूसमॉड टेम्पोर इंकीडिडंट यूटी लेबोर एट डोलोर मैग्ना एलीक्वा।

अध्याय 2: बुद्धिमत्ता को मापना

जैसे-जैसे हम मुख्य यांत्रिकी में गहराई से उतरते हैं, हम पाते हैं कि स्केल करने का सबसे प्रभावी तरीका वितरित नोड्स और विकेंद्रीकृत मेमोरी क्लस्टर के माध्यम से है। केएलई टेक में, हम यह सुनिश्चित करने के लिए इन रणनीतियों को लागू करते हैं कि ज्ञान उच्च-बैंडविड्थ और अल्ट्रा-सुलभ बना रहे...

[पूर्वावलोकन का अंत]`;

const KN_SAMPLE_CONTENT = `ಅಧ್ಯಾಯ 1: ಆಧುನಿಕ ವ್ಯವಸ್ಥೆಗಳ ಅಡಿಪಾಯ

ಡಿಜಿಟಲ್ ತಂತ್ರಜ್ಞಾನದ ವೇಗವಾಗಿ ವಿಕಸನಗೊಳ್ಳುತ್ತಿರುವ ಭೂದೃಶ್ಯದಲ್ಲಿ, ನಮ್ಮ ಮೆದುಳು ಮತ್ತು ನಮ್ಮ ವ್ಯವಸ್ಥೆಗಳ ವಾಸ್ತುಶಿಲ್ಪವು ಹೆಚ್ಚುತ್ತಿರುವ ಸಂಕೀರ್ಣತೆಯನ್ನು ನಿಭಾಯಿಸಲು ಹೊಂದಿಕೊಳ್ಳಬೇಕು. ಈ ಪುಸ್ತಕವು ಈ ತಾಂತ್ರಿಕ ಪರಿಸರಗಳನ್ನು ನಿಯಂತ್ರಿಸುವ ಮೂಲಭೂತ ತತ್ವಗಳನ್ನು ಅನ್ವೇಷಿಸುತ್ತದೆ...

[ಡಿಜಿಟಲ್ ಆರ್ಕೈವ್ ವಿಷಯ]
ಲೋರೆಮ್ ಇಪ್ಸಮ್ ಡಾಲರ್ ಸಿಟ್ ಅಮೆಟ್, ಕಾನ್ಸೆಕ್ಟೆಟರ್ ಅಡಿಪಿಸಿಸಿಂಗ್ ಎಲಿಟ್. ಸೆಡ್ ಡು ಐಯುಸ್ಮೋಡ್ ಟೆಂಪರ್ ಇನ್ಸಿಡಿಡಂಟ್ ಯುಟ್ ಲೇಬರ್ ಎಟ್ ಡಾಲರ್ ಮ್ಯಾಗ್ನಾ ಅಲಿಕ್ವಾ.

ಅಧ್ಯಾಯ 2: ಬುದ್ಧಿವಂತಿಕೆಯನ್ನು ಅಳೆಯುವುದು

ನಾವು ಕೋರ್ ಮೆಕ್ಯಾನಿಕ್ಸ್ ಅನ್ನು ಆಳವಾಗಿ ಅಧ್ಯಯನ ಮಾಡುವಾಗ, ವಿತರಿಸಿದ ನೋಡ್‌ಗಳು ಮತ್ತು ವಿಕೇಂದ್ರೀಕೃತ ಮೆಮೊರಿ ಕ್ಲಸ್ಟರ್‌ಗಳ ಮೂಲಕ ಅಳೆಯಲು ಅತ್ಯಂತ ಪರಿಣಾಮಕಾರಿ ಮಾರ್ಗವಾಗಿದೆ ಎಂದು ನಾವು ಕಂಡುಕೊಳ್ಳುತ್ತೇವೆ. KLE ಟೆಕ್‌ನಲ್ಲಿ, ಜ್ಞಾನವು ಹೆಚ್ಚಿನ ಬ್ಯಾಂಡ್‌ವಿಡ್ತ್ ಮತ್ತು ಅಲ್ಟ್ರಾ-ಅಕ್ಸೆಸಿಬಲ್ ಆಗಿ ಉಳಿಯುವುದನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ನಾವು ಈ ತಂತ್ರಗಳನ್ನು ಬಳಸುತ್ತೇವೆ...

[ಮುನ್ನೋಟದ ಅಂತ್ಯ]`;

const INITIAL_BOOKS: BookItem[] = [
  {
    id: 101,
    title: "Cybersecurity Essentials",
    description: "An essential guide to the fundamentals of cybersecurity, covering network security, compliance, and operational security for modern enterprises.",
    author: "Charles J. Brooks",
    category: "Security",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800",
    translations: {
      HI: {
        title: "साइबर सुरक्षा अनिवार्य",
        description: "आधुनिक उद्यमों के लिए नेटवर्क सुरक्षा, अनुपालन और परिचालन सुरक्षा को कवर करने वाली साइबर सुरक्षा के मूल सिद्धांतों के लिए एक अनिवार्य मार्गदर्शिका।",
        category: "सुरक्षा"
      },
      KN: {
        title: "ಸೈಬರ್ ಸೆಕ್ಯುರಿಟಿ ಎಸೆನ್ಶಿಯಲ್ಸ್",
        description: "ಆಧುನಿಕ ಉದ್ಯಮಗಳಿಗೆ ನೆಟ್‌ವರ್ಕ್ ಭದ್ರತೆ, ಅನುಸರಣೆ ಮತ್ತು ಕಾರ್ಯಾಚರಣೆಯ ಭದ್ರತೆಯನ್ನು ಒಳಗೊಂಡಿರುವ ಸೈಬರ್ ಸೆಕ್ಯುರಿಟಿಯ ಮೂಲಭೂತ ಅಂಶಗಳಿಗೆ ಅಗತ್ಯವಾದ ಮಾರ್ಗದರ್ಶಿ.",
        category: "ಭದ್ರತೆ"
      }
    }
  },
  {
    id: 102,
    title: "Ethical Hacking: A Comprehensive Guide",
    description: "Master the art of penetration testing and vulnerability assessment to secure enterprise environments against sophisticated threats.",
    author: "Peter Kim",
    category: "Security",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 103,
    title: "Cloud Infrastructure & SRE",
    description: "Deep dive into scalable cloud solutions, site reliability engineering, and modern DevOps practices for high-availability systems.",
    author: "Brendan Burns",
    category: "Infrastructure",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 104,
    title: "Modern UI/UX Design Patterns",
    description: "Explore the psychological principles of modern user interface design and implement conversion-focused user experiences.",
    author: "Don Norman",
    category: "Design",
    available: false,
    imageUrl: "https://images.unsplash.com/photo-1586717791821-3f44a563dc4c?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 1,
    title: "Python Programming",
    description: "Learn Python from basics to advanced level. Perfect for beginners and intermediate developers.",
    author: "Alice Johnson",
    category: "Software",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?q=80&w=800&auto=format&fit=crop",
    translations: {
      HI: {
        title: "पायथन प्रोग्रामिंग",
        description: "पायथन को बेसिक से एडवांस लेवल तक सीखें। शुरुआती और मध्यवर्ती डेवलपर्स के लिए बिल्कुल सही।",
        category: "सॉफ्टवेयर"
      },
      KN: {
        title: "ಪೈಥಾನ್ ಪ್ರೋಗ್ರಾಮಿಂಗ್",
        description: "ಪೈಥಾನ್ ಅನ್ನು ಮೂಲಭೂತ ಅಂಶಗಳಿಂದ ಮುಂದುವರಿದ ಹಂತದವರೆಗೆ ಕಲಿಯಿರಿ. ಆರಂಭಿಕ ಮತ್ತು ಮಧ್ಯಂತರ ಡೆವಲಪರ್‌ಗಳಿಗೆ ಸೂಕ್ತವಾಗಿದೆ.",
        category: "ಸಾಫ್ಟ್‌ವೇರ್"
      }
    }
  },
  {
    id: 2,
    title: "Database Systems",
    description: "Learn SQL and database management concepts. Deep dive into relational database design.",
    author: "Bob Smith",
    category: "Data",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1544383333-546e12053916?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 3,
    title: "Artificial Intelligence",
    description: "Explore AI and machine learning technologies. Covers neural networks and deep learning.",
    author: "Charlie Davis",
    category: "Science",
    available: false,
    imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 4,
    title: "Web Development",
    description: "Master HTML, CSS, JavaScript and modern web design with React and frameworks.",
    author: "Dana Lee",
    category: "Software",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: 105,
    title: "Quantum Computing Horizons",
    description: "A formal introduction to quantum algorithms, qubits, and the future of computational supremacy.",
    author: "Michio Kaku",
    category: "Research",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 106,
    title: "Blockchain Decoded",
    description: "Understanding decentralized ledgers, smart contracts, and the architectural shift towards Web3.",
    author: "Andreas Antonopoulos",
    category: "Data",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 107,
    title: "The Art of React",
    description: "Advanced patterns and performance optimization techniques for large-scale enterprise applications.",
    author: "Kent C. Dodds",
    category: "Software",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 108,
    title: "Full Stack Web Security",
    description: "Securing the modern web stack from frontend to database. Practical defense strategies against common exploits.",
    author: "Vikram Oberoi",
    category: "Security",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 109,
    title: "Data Structures & Algorithms",
    description: "The core foundations of computer science. A deep dive into efficient data management and computational logic.",
    author: "Robert Sedgewick",
    category: "Software",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 110,
    title: "Intelligence Engineering",
    description: "Bridging the gap between neural networks and production-ready AI applications. Real-world machine learning deployment.",
    author: "Andrew Ng",
    category: "Research",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 111,
    title: "The Linux Command Line",
    description: "A complete introduction to the terminal, scripting, and the power of the Unix filesystem for developers and sysadmins.",
    author: "William Shotts",
    category: "Infrastructure",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1629654297299-c8506221ca97?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 112,
    title: "Introduction to Data Structures in C",
    description: "A comprehensive guide to managing data efficiently using the C language, specifically tailored for BCA curriculum.",
    author: "Reema Thareja",
    category: "Software",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1516116216624-53e697fedbea?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 113,
    title: "Probability and Statistics for Engineers",
    description: "Foundational concepts of probability theory and statistical analysis for computer science applications.",
    author: "Richard A. Johnson",
    category: "Mathematics",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 114,
    title: "BCA Data Structures & Case Studies",
    description: "Practical implementations of stacks, queues, and linked lists with real-world case studies for BCA students.",
    author: "Seymour Lipschutz",
    category: "Software",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1544383333-546e12053916?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: 115,
    title: "Essentials of Probability and Statistics",
    description: "Simplified mathematical modeling and data analysis techniques for core academic requirements.",
    author: "Mario F. Triola",
    category: "Mathematics",
    available: true,
    imageUrl: "https://images.unsplash.com/photo-1509228627152-72ae9ae6848d?auto=format&fit=crop&q=80&w=800"
  }
];

const TRANSLATIONS = {
  EN: {
    home: "Terminal",
    collections: "Digital Collections",
    blog: "Blog",
    infrastructure: "Architecture",
    support: "E-Support",
    gateway: "Digital Gateway",
    welcome_title: "The Next Era of Learning.",
    hero_desc: "KLEHUB provides an unified digital environment for academic research, high-performance computing resources, and technical archives.",
    explore_collections: "Explore Collections",
    system_specs: "System Specs",
    recent_resources: "Recent Resources",
    catalog_status: "Catalog Status",
    available: "Available",
    borrowed: "Borrowed",
    borrow: "Borrow",
    read_now: "Read Now",
    back: "Back",
    back_to_terminal: "Back to Terminal",
    search_placeholder: "Search the digital archive...",
    dashboard: "Dashboard",
    inventory: "Inventory",
    archive: "Archive",
    settings: "Settings",
    new_resource: "New Resource",
    logout: "Logout",
    profile: "Profile",
    user_management: "User Management",
    system_health: "System Health",
    security: "Security",
    overview: "Overview",
    total_books: "Total Resources",
    active_loans: "Active Nodes",
    categories: "Categories",
    user_status: "Identity Verified",
    recent_activity: "Recent Protocol Updates",
    status_operational: "System Status: Operational",
    student_portal: "Student Portal",
    staff_verification: "Staff Verification",
    active_records: "Active Digital Records",
    network_uptime: "Network Uptime",
    instant_connection: "Instant Connection",
    access_latency: "Access Latency",
    encrypted_storage: "Encrypted Storage",
    system_engineering: "System Engineering",
    core_infrastructure: "Core Infrastructure",
    resource_nodes: "Resource Distributed Nodes",
    biometric_auth: "Biometric User Auth",
    smart_index: "Smart Index Engine",
    view_details: "View Details",
    confirm_borrow: "Confirm Borrow",
    open_reader: "Open Reader",
    currently_unavailable: "Currently Unavailable",
    explore_books: "Explore Books",
    systems_overview: "Systems Overview",
    real_time_metrics: "Real-time metrics for KLEHUB Digital Hub.",
    scan_catalog: "Scan Catalog",
    print_codes: "Print Codes",
    total_catalog: "Total Catalog",
    available_now: "Available Now",
    active_readers: "Active Readers",
    system_latency: "System Latency",
    management_console: "Management Console",
    digital_hub: "Digital Resource Hub"
  },
  HI: {
    home: "टर्मिनल",
    collections: "डिजिटल संग्रह",
    blog: "ब्लॉग",
    infrastructure: "वास्तुशिल्प",
    support: "ई-सहायता",
    gateway: "डिजिटल गेटवे",
    welcome_title: "शिक्षा का अगला युग।",
    hero_desc: "KLEHUB शैक्षणिक अनुसंधान, उच्च प्रदर्शन कंप्यूटिंग संसाधनों और तकनीकी अभिलेखागार के लिए एक एकीकृत डिजिटल वातावरण प्रदान करता है।",
    explore_collections: "संग्रह एक्सप्लोर करें",
    system_specs: "सिस्टम स्पेक्स",
    recent_resources: "हाल के संसाधन",
    catalog_status: "कैटलॉग स्थिति",
    available: "उपलब्ध",
    borrowed: "उधार लिया गया",
    borrow: "उधार लें",
    read_now: "अभी पढ़ें",
    back: "पीछे",
    back_to_terminal: "टर्मिनल पर वापस जाएं",
    search_placeholder: "डिजिटल आर्काइव खोजें...",
    dashboard: "डैशबोर्ड",
    inventory: "इन्वेंटरी",
    archive: "संग्रह",
    settings: "सेटिंग्स",
    new_resource: "नया संसाधन",
    logout: "लॉगआउट",
    profile: "प्रोफ़ाइल",
    user_management: "उपयोगकर्ता प्रबंधन",
    system_health: "सिस्टम हेल्थ",
    security: "सुरक्षा",
    overview: "सिंहावलोकन",
    total_books: "कुल संसाधन",
    active_loans: "सक्रिय नोड्स",
    categories: "श्रेणियाँ",
    user_status: "पहचान सत्यापित",
    recent_activity: "हालिया प्रोटोकॉल अपडेट",
    status_operational: "सिस्टम की स्थिति: चालू",
    student_portal: "छात्र पोर्टल",
    staff_verification: "स्टाफ सत्यापन",
    active_records: "सक्रिय डिजिटल रिकॉर्ड",
    network_uptime: "नेटवर्क अपटाइम",
    instant_connection: "त्वरित कनेक्शन",
    access_latency: "एक्सेस विलंबता",
    encrypted_storage: "एन्क्रिप्टेड स्टोरेज",
    system_engineering: "सिस्टम इंजीनियरिंग",
    core_infrastructure: "कोर इंफ्रास्ट्रक्चर",
    resource_nodes: "संसाधन वितरित नोड्स",
    biometric_auth: "बायोमेट्रिक उपयोगकर्ता प्रमाणीकरण",
    smart_index: "स्मार्ट इंडेक्स इंजन",
    view_details: "विवरण देखें",
    confirm_borrow: "उधार की पुष्टि करें",
    open_reader: "रीडर खोलें",
    currently_unavailable: "वर्तमान में अनुपलब्ध",
    explore_books: "पुस्तकों का अन्वेषण करें",
    systems_overview: "सिस्टम सिंहावलोकन",
    real_time_metrics: "KLEHUB डिजिटल हब के लिए रीयल-टाइम मेट्रिक्स।",
    scan_catalog: "कैटलॉग स्कैन करें",
    print_codes: "कोड प्रिंट करें",
    total_catalog: "कुल कैटलॉग",
    available_now: "अभी उपलब्ध",
    active_readers: "सक्रिय पाठक",
    system_latency: "सिस्टम लेटेंसी",
    management_console: "प्रबंधन कंसोल",
    digital_hub: "डिजिटल संसाधन हब"
  },
  KN: {
    home: "ಟರ್ಮಿನಲ್",
    collections: "ಡಿಜಿಟಲ್ ಸಂಗ್ರಹಗಳು",
    blog: "ಬ್ಲಾಗ್",
    infrastructure: "ವಾಸ್ತುಶಿಲ್ಪ",
    support: "ಇ-ಬೆಂಬಲ",
    gateway: "ಡಿಜಿಟಲ್ ಗೇಟ್‌ವೇ",
    welcome_title: "ಕಲಿಕೆಯ ಮುಂದಿನ ಯುಗ.",
    hero_desc: "KLEHUB ಶೈಕ್ಷಣಿಕ ಸಂಶೋಧನೆ, ಉನ್ನತ-ಕಾರ್ಯಕ್ಷಮತೆಯ ಕಂಪ್ಯೂಟಿಂಗ್ ಸಂಪನ್ಮೂಲಗಳು ಮತ್ತು ತಾಂತ್ರಿಕ ಆರ್ಕೈವ್‌ಗಳಿಗಾಗಿ ಏಕೀಕೃತ ಡಿಜಿಟಲ್ ಪರಿಸರವನ್ನು ಒದಗಿಸುತ್ತದೆ.",
    explore_collections: "ಸಂಗ್ರಹಣೆಗಳನ್ನು ಅನ್ವೇಷಿಸಿ",
    system_specs: "ಸಿಸ್ಟಮ್ ಸ್ಪೆಕ್ಸ್",
    recent_resources: "ಇತ್ತೀಚಿನ ಸಂಪನ್ಮೂಲಗಳು",
    catalog_status: "ಕ್ಯಾಟಲಾಗ್ ಸ್ಥಿತಿ",
    available: "ಲಭ್ಯವಿದೆ",
    borrowed: "ರವಾನಿಸಲಾಗಿದೆ",
    borrow: "ರವಾನೆ",
    read_now: "ಈಗ ಓದಿ",
    back: "ಹಿಂದಕ್ಕೆ",
    back_to_terminal: "ಟರ್ಮಿನಲ್‌ಗೆ ಹಿಂತಿರುಗಿ",
    search_placeholder: "ಡಿಜಿಟಲ್ ಆರ್ಕೈವ್ ಹುಡುಕಿ...",
    dashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    inventory: "ದಾಸ್ತಾನು",
    archive: "ಸಂಗ್ರಹ",
    settings: "ಸೆಟ್ಟಿಂಗ್‌ಗಳು",
    new_resource: "ಹೊಸ ಸಂಪನ್ಮೂಲ",
    logout: "ಲಾಗ್ ಔಟ್",
    profile: "ಪ್ರೊಫೈಲ್",
    user_management: "ಬಳಕೆದಾರ ನಿರ್ವಹಣೆ",
    system_health: "ಸಿಸ್ಟಮ್ ಆರೋಗ್ಯ",
    security: "ಭದ್ರತೆ",
    overview: "ಅವಲೋಕನ",
    total_books: "ಒಟ್ಟು ಸಂಪನ್ಮೂಲಗಳು",
    active_loans: "ಸಕ್ರಿಯ ನೋಡ್‌ಗಳು",
    categories: "ವರ್ಗಗಳು",
    user_status: "ಗುರುತು ದೃಢೀಕರಿಸಲಾಗಿದೆ",
    recent_activity: "ಇತ್ತೀಚಿನ ಪ್ರೋಟೋಕಾಲ್ ನವೀಕರಣಗಳು",
    status_operational: "ಸಿಸ್ಟಮ್ ಸ್ಥಿತಿ: ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿದೆ",
    student_portal: "ವಿದ್ಯಾರ್ಥಿ ಪೋರ್ಟಲ್",
    staff_verification: "ಸಿಬ್ಬಂದಿ ಪರಿಶೀಲನೆ",
    active_records: "ಸಕ್ರಿಯ ಡಿಜಿಟಲ್ ದಾಖಲೆಗಳು",
    network_uptime: "ನೆಟ್‌ವರ್ಕ್ ಅಪ್ಟೈಮ್",
    instant_connection: "ತತ್ಕ್ಷಣದ ಸಂಪರ್ಕ",
    access_latency: "ಪ್ರವೇಶ ವಿಳಂಬ",
    encrypted_storage: "ಎನ್‌ಕ್ರಿಪ್ಟ್ ಮಾಡಿದ ಸಂಗ್ರಹಣೆ",
    system_engineering: "ಸಿಸ್ಟಮ್ ಇಂಜಿನಿಯರಿಂಗ್",
    core_infrastructure: "ಮೂಲ ಮೂಲಸೌಕರ್ಯ",
    resource_nodes: "ಸಂಪನ್ಮೂಲ ವಿತರಿಸಿದ ನೋಡ್‌ಗಳು",
    biometric_auth: "ಬಯೋಮೆಟ್ರಿಕ್ ಬಳಕೆದಾರ ದೃಢೀಕರಣ",
    smart_index: "ಸ್ಮಾರ್ಟ್ ಸೂಚ್ಯಂಕ ಎಂಜಿನ್",
    view_details: "ವಿವರಗಳನ್ನು ನೋಡಿ",
    confirm_borrow: "ರವಾನೆಯನ್ನು ಖಚಿತಪಡಿಸಿ",
    open_reader: "ರೀಡರ್ ತೆರೆಯಿರಿ",
    currently_unavailable: "ಪ್ರಸ್ತುತ ಲಭ್ಯವಿಲ್ಲ",
    explore_books: "ಪುಸ್ತಕಗಳನ್ನು ಅನ್ವೇಷಿಸಿ",
    systems_overview: "ಸಿಸ್ಟಮ್ ಅವಲೋಕನ",
    real_time_metrics: "KLEHUB ಡಿಜಿಟಲ್ ಹಬ್‌ಗಾಗಿ ನೈಜ-ಸಮಯದ ಮೆಟ್ರಿಕ್ಸ್.",
    scan_catalog: "ಕ್ಯಾಟಲಾಗ್ ಸ್ಕ್ಯಾನ್ ಮಾಡಿ",
    print_codes: "ಕೋಡ್‌ಗಳನ್ನು ಮುದ್ರಿಸಿ",
    total_catalog: "ಒಟ್ಟು ಕ್ಯಾಟಲಾಗ್",
    available_now: "ಈಗ ಲಭ್ಯವಿದೆ",
    active_readers: "ಸಕ್ರಿಯ ಓದುಗರು",
    system_latency: "ಸಿಸ್ಟಮ್ ವಿಳಂಬ",
    management_console: "ನಿರ್ವಹಣಾ ಕನ್ಸೋಲ್",
    digital_hub: "ಡಿಜಿಟಲ್ ಸಂಪನ್ಮೂಲ ಹಬ್"
  }
};

export default function App() {
  const [role, setRole] = useState<UserRole>('guest');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'inventory' | 'settings' | 'archive'>('dashboard');
  const [authStep, setAuthStep] = useState<'selection' | 'login'>('selection');
  const [guestSubPage, setGuestSubPage] = useState<'home' | 'collections' | 'infrastructure' | 'support' | 'blog'>('home');
  const [currentlyReading, setCurrentlyReading] = useState<BookItem | null>(null);

  const [tempRole, setTempRole] = useState<UserRole | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<any>(null);

  const blogPosts = [
    {
      id: 1,
      category: "Engineering",
      title: "Integrating AI into Academic Research Workflows",
      author: "Dr. Aris Thorne",
      date: "May 12, 2026",
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=1200",
      content: "As artificial intelligence continues to reshape the landscape of higher education, researchers at KLE Technological University are pioneering new methods to integrate large language models and machine learning into traditional library workflows. This integration allows for faster data crawling and better semantic understanding of cross-departmental research papers."
    },
    {
      id: 2,
      category: "Infrastructure",
      title: "Quantum Computing Resources Added to Catalog",
      author: "Tech Archives Team",
      date: "May 10, 2026",
      image: "https://images.unsplash.com/photo-1491841573634-28140fc7ced7?auto=format&fit=crop&q=80&w=600",
      content: "We have successfully indexed over 500 new technical papers on quantum supremacy and cryptographic algorithms into Cluster B. These resources are now available for all students with Level 2 verification. The additions focus on superconducting circuits and topological quantum computing."
    },
    {
      id: 3,
      category: "Events",
      title: "KLE Tech Hackathon: Library Edition",
      author: "Student Council",
      date: "May 08, 2026",
      image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=600",
      content: "The upcoming hackathon will focus on improving digital accessibility and building decentralized search nodes for the KLEHUB platform. Join us this weekend for 48 hours of intense coding and innovation. Prizes include cloud infrastructure credits and research fellowships."
    }
  ];

  const renderBlogPostDetail = () => (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto"
    >
      <button 
        onClick={() => setSelectedPost(null)}
        className="mb-12 flex items-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:translate-x-2 transition-transform"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Blog List
      </button>
      
      <div className="aspect-[21/9] rounded-[48px] overflow-hidden mb-12 shadow-2xl">
        <img src={selectedPost.image} className="w-full h-full object-cover" alt={selectedPost.title} referrerPolicy="no-referrer" />
      </div>

      <div className="flex items-center gap-4 text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">
        <span>{selectedPost.date}</span>
        <span className="w-1 h-1 bg-slate-300 rounded-full" />
        <span className="text-indigo-600 underline">#{selectedPost.category}</span>
        <span className="w-1 h-1 bg-slate-300 rounded-full" />
        <span>By {selectedPost.author}</span>
      </div>

      <h2 className="text-5xl md:text-6xl font-black text-slate-950 uppercase tracking-tighter leading-none mb-10">
        {selectedPost.title}
      </h2>

      <div className="prose prose-slate max-w-none">
        <p className="text-xl text-slate-600 font-medium leading-relaxed mb-6">
          {selectedPost.content}
        </p>
        <p className="text-lg text-slate-500 leading-relaxed">
          KLEHUB is committed to fostering a culture of innovation and continuous learning. By providing access to cutting-edge technologies and diverse architectural perspectives, we empower our students to lead in their respective fields.
        </p>
      </div>
    </motion.div>
  );
  const [books, setBooks] = useState<BookItem[]>(() => {
    const saved = localStorage.getItem('library_inventory_v2');
    return saved ? JSON.parse(saved) : INITIAL_BOOKS.map(b => ({ ...b, fullContent: SAMPLE_CONTENT }));
  });

  const handleBorrow = (bookId: number) => {
    setBooks(prev => {
      const updated = prev.map(book => {
        if (book.id === bookId) {
          return { ...book, available: false, borrowedBy: 'current-user-123' };
        }
        return book;
      });
      localStorage.setItem('library_inventory_v2', JSON.stringify(updated));
      return updated;
    });
  };

  useEffect(() => {
    localStorage.setItem('library_inventory_v2', JSON.stringify(books));
  }, [books]);

  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<BookItem | null>(null);
  const [viewingBook, setViewingBook] = useState<BookItem | null>(null);
  const [currentLang, setCurrentLang] = useState<'EN' | 'HI' | 'KN'>('EN');
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);

  const t = (key: keyof (typeof TRANSLATIONS)['EN']) => {
    return (TRANSLATIONS[currentLang] as any)[key] || key;
  };

  const getTranslatedBook = (book: BookItem): BookItem => {
    if (currentLang === 'EN') return book;
    const trans = book.translations?.[currentLang as 'HI' | 'KN'];
    if (!trans) return book;
    
    return {
      ...book,
      title: trans.title || book.title,
      description: trans.description || book.description,
      category: trans.category || book.category,
      fullContent: trans.fullContent || (currentLang === 'HI' ? HI_SAMPLE_CONTENT : currentLang === 'KN' ? KN_SAMPLE_CONTENT : book.fullContent)
    };
  };


  // User Info (Mocked from metadata/role)
  const userInfo = useMemo(() => {
    if (role === 'student') return {
      name: "Rithwik Sajjan",
      id: "STU-2026-0942",
      dept: "Computer Science & Engineering",
      email: "rithwiksajjan06@gmail.com",
      avatar: "RS"
    };
    return {
      name: "Sarah Sterling",
      id: "ADM-2026-0001",
      dept: "Library Administration",
      email: "admin@kle.edu",
      avatar: "SS"
    };
  }, [role]);

  // Form State
  const [newTitle, setNewTitle] = useState("");
  const [newAuthor, setNewAuthor] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newCategory, setNewCategory] = useState("Software");
  const [newImageUrl, setNewImageUrl] = useState("");

  const filteredBooks = useMemo(() => {
    return books
      .filter(book => 
        book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        book.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        book.author.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .map(book => getTranslatedBook(book));
  }, [books, searchTerm, currentLang]);

  const resetForm = () => {
    setNewTitle("");
    setNewAuthor("");
    setNewDesc("");
    setNewCategory("Software");
    setNewImageUrl("");
    setEditingBook(null);
  };

  const handleAddOrUpdate = (e: FormEvent) => {
    e.preventDefault();
    if (editingBook) {
      setBooks(prev => prev.map(b => b.id === editingBook.id ? {
        ...b,
        title: newTitle,
        author: newAuthor,
        description: newDesc,
        category: newCategory,
        imageUrl: newImageUrl
      } : b));
    } else {
      const newBook: BookItem = {
        id: Date.now(),
        title: newTitle,
        author: newAuthor,
        description: newDesc,
        category: newCategory,
        imageUrl: newImageUrl,
        available: true
      };
      setBooks(prev => [newBook, ...prev]);
    }
    setIsModalOpen(false);
    resetForm();
  };

  const handleDelete = (id: number) => {
    setBooks(prev => prev.filter(b => b.id !== id));
    if (viewingBook?.id === id) setViewingBook(null);
  };

  const openEdit = (book: BookItem) => {
    setEditingBook(book);
    setNewTitle(book.title);
    setNewAuthor(book.author);
    setNewDesc(book.description);
    setNewCategory(book.category);
    setNewImageUrl(book.imageUrl || "");
    setIsModalOpen(true);
  };

  if (role === 'guest') {
    return (
      <div className="min-h-screen bg-white flex flex-col font-sans">
        <header className="h-20 border-b border-slate-100 px-8 flex items-center justify-between sticky top-0 z-50 bg-white/80 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnu3_NV41wNtPV0D7Ugsvb2W7EYlOaBFUkOg&s" className="w-8 h-8 object-contain" alt="KLEHUB Logo" referrerPolicy="no-referrer" />
            <span className="text-xl font-black text-slate-900 tracking-tighter uppercase">KLEHUB</span>
          </div>
          <nav className="hidden md:flex gap-8 text-[10px] font-black text-slate-500 uppercase tracking-widest">
            <button 
              onClick={() => setGuestSubPage('home')}
              className={`hover:text-indigo-600 transition-colors uppercase flex items-center gap-2 ${guestSubPage === 'home' ? 'text-indigo-600' : ''}`}
            >
              <Home className="w-3 h-3" /> {t('home')}
            </button>
            <button 
              onClick={() => setGuestSubPage('collections')}
              className={`hover:text-indigo-600 transition-colors uppercase ${guestSubPage === 'collections' ? 'text-indigo-600' : ''}`}
            >
              {t('collections')}
            </button>
            <button 
              onClick={() => setGuestSubPage('blog')}
              className={`hover:text-indigo-600 transition-colors uppercase flex items-center gap-2 ${guestSubPage === 'blog' ? 'text-indigo-600' : ''}`}
            >
              <Library className="w-3 h-3" /> {t('blog')}
            </button>
            <button 
              onClick={() => setGuestSubPage('infrastructure')}
              className={`hover:text-indigo-600 transition-colors uppercase ${guestSubPage === 'infrastructure' ? 'text-indigo-600' : ''}`}
            >
              {t('infrastructure')}
            </button>
            <button 
              onClick={() => setGuestSubPage('support')}
              className={`hover:text-indigo-600 transition-colors uppercase ${guestSubPage === 'support' ? 'text-indigo-600' : ''}`}
            >
              {t('support')}
            </button>

          </nav>
          <div className="flex items-center gap-4">
            <div className="relative">
              <button 
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                className="flex items-center gap-2 px-3 py-1.5 hover:bg-slate-50 rounded-lg transition-colors group"
              >
                <Languages className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest group-hover:text-slate-900">{currentLang}</span>
              </button>
              
              <AnimatePresence>
                {isLangMenuOpen && (
                  <>
                    <div 
                      className="fixed inset-0 z-[60]" 
                      onClick={() => setIsLangMenuOpen(false)}
                    />
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 mt-2 w-48 bg-white border border-slate-100 rounded-2xl shadow-xl z-[70] p-2 overflow-hidden"
                    >
                      {[
                        { code: 'EN', label: 'English' },
                        { code: 'HI', label: 'Hindi (हिंदी)' },
                        { code: 'KN', label: 'Kannada (ಕನ್ನಡ)' }
                      ].map((lang) => (
                        <button
                          key={lang.code}
                          onClick={() => {
                            setCurrentLang(lang.code as any);
                            setIsLangMenuOpen(false);
                          }}
                          className={`w-full text-left px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${currentLang === lang.code ? 'bg-indigo-50 text-indigo-600' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'}`}
                        >
                          {lang.label}
                        </button>
                      ))}
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
            <button 
              onClick={() => setAuthStep('login')}
              className="bg-slate-900 text-white px-6 py-3 rounded-xl font-black text-[10px] tracking-widest uppercase hover:bg-indigo-600 transition-all"
            >
              {t('gateway')}
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {authStep === 'selection' ? (
            <motion.div 
              key="selection"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 flex flex-col"
            >
              {guestSubPage === 'home' ? (
                <>
                  {/* HERO SECTION */}
                  <section className="py-24 px-8 border-b border-slate-100 bg-slate-50/50">
                    <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
                      <div>
                        <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest mb-6">
                          <ShieldCheck className="w-3" /> {t('status_operational')}
                        </div>
                        <h1 className="text-7xl font-black text-slate-900 tracking-tighter leading-[0.85] uppercase mb-8">
                          {t('welcome_title').split(' ').map((word, i) => (
                            <span key={i}>{word} <br /> </span>
                          ))}
                        </h1>
                        <p className="text-xl text-slate-500 font-medium leading-relaxed max-w-lg mb-12">
                          {t('hero_desc')}
                        </p>
                        <div className="flex flex-wrap gap-4">
                          <button 
                            onClick={() => {
                              setTempRole('student');
                              setAuthStep('login');
                            }}
                            className="group bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-4 transition-all hover:scale-[1.02] shadow-2xl shadow-indigo-200"
                          >
                            {t('student_portal')} <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-all" />
                          </button>
                          <button 
                            onClick={() => {
                              setTempRole('employee');
                              setAuthStep('login');
                            }}
                            className="bg-white border-2 border-slate-200 text-slate-600 px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-all"
                          >
                            {t('staff_verification')}
                          </button>
                        </div>

                      </div>
                      <div className="relative">
                        <div className="aspect-square bg-indigo-600 rounded-[80px] overflow-hidden shadow-2xl rotate-3 relative">
                          <img 
                            src="https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80&w=1200" 
                            alt="Modern Library"
                            className="w-full h-full object-cover transition-transform duration-1000 hover:scale-110"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="absolute -bottom-8 -left-8 bg-white p-8 rounded-[40px] shadow-2xl border border-slate-100 max-w-xs -rotate-6">
                          <p className="text-3xl font-black text-slate-900 tracking-tight leading-none mb-2">12k+</p>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('active_records')}</p>
                        </div>

                      </div>
                    </div>
                  </section>

                  {/* STATS SECTION - High Intensity */}
                  <section className="py-24 px-8 bg-slate-50">
                    <div className="max-w-7xl mx-auto">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                         {[
                           { val: "99.9%", label: t('network_uptime'), icon: <ShieldCheck className="w-6 h-6" /> },
                           { val: "24/7", label: t('instant_connection'), icon: <Database className="w-6 h-6" /> },
                           { val: "50ms", label: t('access_latency'), icon: <Settings className="w-6 h-6" /> },
                           { val: "VAULT", label: t('encrypted_storage'), icon: <Library className="w-6 h-6" /> }
                         ].map((stat, i) => (

                           <motion.div 
                            key={i}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.1 }}
                            className="group bg-white p-10 rounded-[40px] border border-slate-200 hover:border-indigo-500 transition-all hover:-translate-y-2 cursor-default shadow-sm hover:shadow-xl hover:shadow-indigo-500/5"
                           >
                              <div className="text-indigo-600 mb-6 group-hover:scale-110 transition-transform">{stat.icon}</div>
                              <p className="text-5xl font-black text-slate-950 mb-2 leading-none tracking-tighter">{stat.val}</p>
                              <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest leading-none">{stat.label}</p>
                           </motion.div>
                         ))}
                      </div>
                    </div>
                  </section>

                  {/* ARCHITECTURE PREVIEW - Clean Grid */}
                  <section className="py-32 px-8 bg-white overflow-hidden relative">
                     <div className="max-w-7xl mx-auto relative z-10">
                        <div className="flex flex-col md:flex-row justify-between items-end gap-12 mb-20">
                           <div>
                             <p className="text-indigo-600 font-extrabold text-[10px] uppercase tracking-[0.3em] mb-4">Core Infrastructure</p>
                             <h2 className="text-6xl md:text-7xl font-black tracking-tighter text-slate-950 uppercase leading-[0.85]">System <br /> Engineering.</h2>
                           </div>
                           <p className="text-slate-500 font-medium max-w-sm mb-2 text-lg leading-relaxed">
                             "Proprietary distribution algorithms designed for high-concurrency academic environments."
                           </p>
                        </div>
                        <div className="grid md:grid-cols-3 gap-8">
                           <div 
                             onClick={() => setGuestSubPage('collections')}
                             className="p-12 border border-slate-200 rounded-[56px] bg-slate-50 group hover:bg-slate-950 hover:text-white transition-all duration-500 shadow-sm cursor-pointer"
                           >
                              <Database className="w-12 h-12 text-indigo-600 mb-10 group-hover:scale-110 transition-transform" />
                              <h4 className="text-2xl font-black mb-6 uppercase tracking-tight leading-none">Resource <br /> Distributed Nodes</h4>
                              <p className="text-sm font-medium leading-relaxed opacity-70">Catalog resources are mirrored across decentralized campus servers to eliminate downtime.</p>
                           </div>
                           <div 
                             onClick={() => setGuestSubPage('infrastructure')}
                             className="p-12 border border-slate-200 rounded-[56px] bg-white group hover:bg-indigo-600 hover:text-white transition-all duration-500 shadow-sm cursor-pointer"
                           >
                              <LayoutDashboard className="w-12 h-12 text-indigo-600 group-hover:text-white mb-10 group-hover:scale-110 transition-transform" />
                              <h4 className="text-2xl font-black mb-6 uppercase tracking-tight leading-none">Biometric <br /> User Auth</h4>
                              <p className="text-sm font-medium leading-relaxed opacity-70">Enhanced encryption protocols protect institutional ID data and user metadata integrity.</p>
                           </div>
                           <div 
                             onClick={() => setGuestSubPage('support')}
                             className="p-12 border border-slate-200 rounded-[56px] bg-slate-50 group hover:bg-slate-950 hover:text-white transition-all duration-500 shadow-sm cursor-pointer"
                           >
                              <Settings className="w-12 h-12 text-indigo-600 mb-10 group-hover:scale-110 transition-transform" />
                              <h4 className="text-2xl font-black mb-6 uppercase tracking-tight leading-none">Smart <br /> Index Engine</h4>
                              <p className="text-sm font-medium leading-relaxed opacity-70">Our searching algorithms predict research needs based on departmental course structures.</p>
                           </div>
                        </div>
                     </div>
                  </section>
                </>
              ) : guestSubPage === 'collections' ? (
                <section className="py-24 px-8 min-h-screen animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="max-w-6xl mx-auto">
                    <button 
                      onClick={() => setGuestSubPage('home')}
                      className="mb-12 flex items-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:translate-x-2 transition-transform"
                    >
                      <ArrowLeft className="w-4 h-4" /> {t('back_to_terminal')}
                    </button>
                    <h2 className="text-6xl font-black text-slate-900 tracking-tighter uppercase mb-4 leading-none">{t('collections')}.</h2>

                    <p className="text-xl text-slate-500 font-medium mb-16 max-w-2xl">
                      Explore our vast distributed database of academic assets, organized by discipline and technical complexity.
                    </p>
                    
                    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
                      {['Software', 'Security', 'Infrastructure', 'Science'].map((cat) => (
                        <div key={cat} className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-xl shadow-slate-100">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{cat}</p>
                          <p className="text-4xl font-black text-slate-900 mb-4">{books.filter(b => b.category === cat).length}</p>
                          <div className="h-1 w-8 bg-indigo-600 rounded-full" />
                        </div>
                      ))}
                    </div>

                    <div className="grid md:grid-cols-3 gap-12">
                      <div className="md:col-span-2 space-y-12">
                        <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Trending Resources</h3>
                        {books.slice(0, 3).map(book => (
                          <div key={book.id} className="flex gap-8 items-start group">
                            <div className="w-32 h-40 bg-slate-100 rounded-2xl overflow-hidden shadow-lg group-hover:scale-105 transition-transform">
                              <img src={book.imageUrl} className="w-full h-full object-cover" />
                            </div>
                            <div className="flex-1">
                              <span className="text-[9px] font-black bg-indigo-50 text-indigo-600 px-2 py-1 rounded-md mb-2 inline-block uppercase tracking-widest">{book.category}</span>
                              <h4 className="text-xl font-black text-slate-900 mb-2 truncate">{book.title}</h4>
                              <p className="text-sm text-slate-500 leading-relaxed mb-4">{book.description}</p>
                              <button 
                                onClick={() => {
                                  setViewingBook(book);
                                }}
                                className="text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline"
                              >
                                View Specs
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="space-y-8">
                        <div className="bg-slate-900 text-white p-10 rounded-[40px] shadow-2xl">
                          <h4 className="text-xl font-black uppercase tracking-tight mb-6">Archive Access</h4>
                          <p className="text-sm text-slate-400 leading-relaxed mb-8 font-medium">Archived papers and legacy manuals are available for terminal-level users only. Authenticate to unlock full access.</p>
                          <button 
                            onClick={() => setAuthStep('login')}
                            className="w-full bg-indigo-600 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-indigo-900/50 hover:bg-indigo-500 transition-colors"
                          >
                            Authenticate Now
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              ) : guestSubPage === 'blog' ? (
                <section className="py-24 px-8 min-h-screen animate-in fade-in slide-in-from-bottom-4 duration-500 bg-white">
                  <div className="max-w-7xl mx-auto">
                    {selectedPost ? (
                      renderBlogPostDetail()
                    ) : (
                      <>
                        <button 
                          onClick={() => setGuestSubPage('home')}
                          className="mb-12 flex items-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:translate-x-2 transition-transform"
                        >
                          <ArrowLeft className="w-4 h-4" /> Back to Terminal
                        </button>
                        
                        <div className="flex flex-col md:flex-row justify-between items-end gap-12 mb-20">
                          <div>
                            <p className="text-indigo-600 font-extrabold text-[10px] uppercase tracking-[0.3em] mb-4">Academic Insights</p>
                            <h2 className="text-6xl md:text-8xl font-black tracking-tighter text-slate-950 uppercase leading-none">The <br /> Library <br /> Blog.</h2>
                          </div>
                          <p className="text-slate-500 font-medium max-w-sm mb-2 text-lg leading-relaxed">
                            Stay updated with the latest in digital research, institutional news, and library technology trends.
                          </p>
                        </div>

                        <div className="grid lg:grid-cols-3 gap-12">
                          {/* Featured Post */}
                          <div 
                            onClick={() => setSelectedPost(blogPosts[0])}
                            className="lg:col-span-2 group cursor-pointer"
                          >
                            <div className="aspect-[16/9] rounded-[48px] overflow-hidden mb-8 shadow-2xl relative">
                              <img 
                                src={blogPosts[0].image} 
                                alt="Featured Blog" 
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                              <div className="absolute bottom-10 left-10 text-white">
                                <span className="bg-indigo-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-4 inline-block">Featured</span>
                                <h3 className="text-4xl font-black leading-tight uppercase tracking-tighter">{blogPosts[0].title}</h3>
                              </div>
                            </div>
                            <div className="flex items-center gap-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                              <span>{blogPosts[0].date}</span>
                              <span className="w-1 h-1 bg-slate-300 rounded-full" />
                              <span>{blogPosts[0].author}</span>
                            </div>
                          </div>

                          {/* Side List */}
                          <div className="space-y-10">
                            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] border-b border-slate-100 pb-4">Recent Updates</h4>
                            {blogPosts.slice(1).concat([
                              { id: 4, category: "Security", title: "Cybersecurity in Institutional Databases", date: "May 05", author: "DevOps Team", image: "", content: "" },
                              { id: 5, category: "Architecture", title: "The Evolution of Shared Learning Spaces", date: "May 01", author: "Design Group", image: "", content: "" }
                            ] as any[]).map((post) => (
                              <div 
                                key={post.id} 
                                onClick={() => post.image && setSelectedPost(post)}
                                className={`group cursor-pointer ${!post.image ? 'opacity-50 hover:opacity-100' : ''}`}
                              >
                                <p className="text-indigo-600 text-[9px] font-black uppercase tracking-widest mb-2">{post.category}</p>
                                <h5 className="text-xl font-black text-slate-950 uppercase tracking-tight leading-tight group-hover:text-indigo-600 transition-colors mb-2">{post.title}</h5>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{post.date}, 2026</p>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="mt-32 grid md:grid-cols-3 gap-8">
                           {blogPosts.slice(1, 3).concat([
                             {
                               id: 6,
                               category: "Science",
                               image: "https://images.unsplash.com/photo-1544652478-6653e09f18a2?auto=format&fit=crop&q=80&w=600",
                               title: "System Update: Enhanced Search Latency",
                               date: "May 02, 2026",
                               author: "System Admin",
                               content: "New indexing algorithms reduce cross-node search latency by up to 40% using advanced caching layers."
                             }
                           ]).map((post) => (
                             <div 
                               key={post.id} 
                               onClick={() => setSelectedPost(post)}
                               className="bg-slate-50 rounded-[48px] overflow-hidden border border-slate-100 group cursor-pointer hover:shadow-2xl transition-all"
                             >
                               <div className="aspect-video relative overflow-hidden">
                                 <img src={post.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt={post.title} referrerPolicy="no-referrer" />
                               </div>
                               <div className="p-10">
                                  <h4 className="text-2xl font-black text-slate-950 uppercase tracking-tight leading-none mb-4">{post.title}</h4>
                                  <p className="text-sm text-slate-500 font-medium leading-relaxed line-clamp-2">{post.content}</p>
                               </div>
                             </div>
                           ))}
                        </div>
                      </>
                    )}
                  </div>
                </section>
              ) : guestSubPage === 'infrastructure' ? (
                <section className="py-24 px-8 min-h-screen animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="max-w-6xl mx-auto">
                    <button 
                      onClick={() => setGuestSubPage('home')}
                      className="mb-12 flex items-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:translate-x-2 transition-transform"
                    >
                      <ArrowLeft className="w-4 h-4" /> {t('back_to_terminal')}
                    </button>
                    <h2 className="text-6xl font-black text-slate-900 tracking-tighter uppercase mb-4 leading-none">System <br /> Backbone.</h2>

                    <p className="text-xl text-slate-500 font-medium mb-16 max-w-2xl">
                      KLEHUB is powered by a private distributed network, ensuring maximum throughput and cryptographic data integrity.
                    </p>

                    <div className="grid lg:grid-cols-3 gap-8 mb-20">
                      <div className="lg:col-span-2 bg-slate-900 rounded-[60px] p-16 text-white relative overflow-hidden">
                        <div className="relative z-10 flex flex-col h-full">
                          <div className="flex items-center gap-4 mb-20">
                            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 flex items-center justify-center border border-emerald-500/30">
                              <ShieldCheck className="w-6 h-6 text-emerald-400" />
                            </div>
                            <div>
                               <p className="text-sm font-black uppercase tracking-tight">Security Gateway</p>
                               <p className="text-xs text-emerald-500 font-bold">STATUS: REINFORCED</p>
                            </div>
                          </div>
                          
                          <h3 className="text-4xl font-black uppercase tracking-tighter mb-8 italic">"Encrypted at <br /> the hardware <br /> level."</h3>
                          <div className="grid grid-cols-2 gap-12 mt-auto">
                             <div>
                                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Protocol</p>
                                <p className="text-xl font-bold">AES-256 GCM</p>
                             </div>
                             <div>
                                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Network</p>
                                <p className="text-xl font-bold">Zero-Trust</p>
                             </div>
                          </div>
                        </div>
                        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/20 blur-[100px] rounded-full translate-x-1/2 -translate-y-1/2" />
                      </div>
                      <div className="bg-white border-2 border-slate-100 rounded-[60px] p-12 flex flex-col justify-center">
                         <div className="space-y-10">
                            {[
                              { label: 'Cluster nodes', val: '42 Active' },
                              { label: 'Storage pool', val: '1.2 PB' },
                              { label: 'Response time', val: '< 24ms' },
                              { label: 'Backup freq', val: '5 min' }
                            ].map(item => (
                              <div key={item.label}>
                                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{item.label}</p>
                                 <p className="text-2xl font-black text-slate-900 tracking-tight">{item.val}</p>
                              </div>
                            ))}
                         </div>
                      </div>
                    </div>
                  </div>
                </section>
              ) : (
                <section className="py-24 px-8 min-h-screen animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="max-w-6xl mx-auto">
                    <button 
                      onClick={() => setGuestSubPage('home')}
                      className="mb-12 flex items-center gap-2 text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:translate-x-2 transition-transform"
                    >
                      <ArrowLeft className="w-4 h-4" /> Back to Terminal
                    </button>
                    <h2 className="text-6xl font-black text-slate-900 tracking-tighter uppercase mb-4 leading-none">Electronic <br /> Support.</h2>
                    <p className="text-xl text-slate-500 font-medium mb-16 max-w-2xl">
                      Encountering system anomalies? Our technical desk is operational 24/7 for hardware and administrative queries.
                    </p>

                    <div className="grid md:grid-cols-2 gap-16">
                      <div className="bg-white p-12 rounded-[60px] border border-slate-100 shadow-2xl shadow-slate-100">
                        <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight mb-8">Technical Desk</h3>
                        <form className="space-y-6">
                           <div>
                              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Institutional ID</label>
                              <input type="text" placeholder="STU-XXXX" className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-bold" />
                           </div>
                           <div>
                              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Problem Category</label>
                              <select className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-bold">
                                 <option>Access Credentials</option>
                                 <option>Resource Sync</option>
                                 <option>Hardware Failure</option>
                                 <option>Other</option>
                              </select>
                           </div>
                           <div>
                              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Manifest</label>
                              <textarea rows={4} placeholder="Describe the system anomaly..." className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-bold"></textarea>
                           </div>
                           <button className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-slate-200 hover:bg-indigo-600 transition-all">Submit Ticket</button>
                        </form>
                      </div>
                      <div className="flex flex-col justify-center space-y-12">
                         <div>
                            <h4 className="text-xl font-black text-slate-900 uppercase tracking-tight mb-4">Urgent Inquiries</h4>
                            <div className="space-y-4">
                               <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                                     <Mail className="w-5 h-5" />
                                  </div>
                                  <p className="text-sm font-bold text-slate-600">support@klehub.edu</p>
                               </div>
                               <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                                     <Info className="w-5 h-5" />
                                  </div>
                                  <p className="text-sm font-bold text-slate-600">+91 080-2345678</p>
                               </div>
                            </div>
                         </div>
                         <div className="p-10 bg-indigo-50 rounded-[40px] border border-indigo-100">
                            <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-2">Infrastructure Alert</p>
                            <p className="text-sm text-slate-600 leading-relaxed font-medium italic">"System logs indicate peak traffic between 14:00 - 16:00 UTC. Expect potential latency in legacy archives."</p>
                         </div>
                      </div>
                    </div>
                  </div>
                </section>
              )}

              <footer className="py-12 border-t border-slate-100 mt-auto bg-white px-8">
                <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">© 2026 KLE Technological University. All Systems Terminal.</p>
                   <div className="flex gap-8 text-[10px] font-black text-slate-900 uppercase tracking-widest">
                      <a href="#" className="hover:text-indigo-600 transition-colors">Privacy</a>
                      <a href="#" className="hover:text-indigo-600 transition-colors">Security</a>
                      <a href="#" className="hover:text-indigo-600 transition-colors">Terms</a>
                   </div>
                </div>
              </footer>
            </motion.div>
          ) : (
            <motion.div 
              key="login"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-md w-full"
            >
              <div className="bg-white p-12 rounded-[40px] shadow-2xl shadow-indigo-100 border border-slate-100 relative shadow-[0_32px_64px_-16px_rgba(79,70,229,0.1)]">
                <button 
                  onClick={() => setAuthStep('selection')}
                  className="absolute top-8 left-8 text-slate-400 hover:text-indigo-600 transition-colors"
                >
                  <ArrowLeft className="w-6 h-6" />
                </button>

                <div className="text-center mt-8 mb-12">
                  <div className="w-20 h-20 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
                    <User className="w-10 h-10 text-indigo-600" />
                  </div>
                  <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tight leading-none mb-2">
                    {tempRole === 'student' ? 'Student Portal' : 'Staff Access'}
                  </h2>
                  <p className="text-slate-500 font-medium px-4">Enter your institutional credentials to authenticate your session.</p>
                </div>

                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (tempRole) setRole(tempRole);
                  }}
                  className="space-y-6 px-4 pb-4"
                >
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">Institutional Identifier</label>
                    <input 
                      type="text" 
                      placeholder={tempRole === 'student' ? "STU-202X-XXXX" : "EMP-202X-XXXX"}
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-all font-bold text-slate-900 placeholder:text-slate-300"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block px-1">Access Passphrase</label>
                    <input 
                      type="password" 
                      placeholder="••••••••"
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-all font-bold text-slate-900 placeholder:text-slate-300"
                      required
                    />
                  </div>
                  
                  <div className="pt-4">
                    <button 
                      type="submit"
                      className="w-full bg-slate-900 text-white p-6 rounded-3xl font-black text-xs uppercase tracking-widest transition-all hover:bg-slate-800 active:scale-95 shadow-xl shadow-slate-200 mb-6"
                    >
                      INITIALIZE SESSION
                    </button>
                    <div className="flex flex-col items-center gap-2">
                      <p className="text-xs font-bold text-slate-400">Secure Authentication Protocol v2.4.0</p>
                      <button type="button" className="text-[10px] font-black text-indigo-600 hover:underline uppercase tracking-wider">Account Recovery Request</button>
                    </div>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* PROFESSIONAL NAVBAR */}
      <header className="h-20 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setRole('guest')}
            className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="w-px h-6 bg-slate-200 mx-2" />
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-lg shadow-indigo-100 overflow-hidden border border-slate-100">
              <img src={LOGO_IMAGE} alt="KLE Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <h1 className="text-lg font-black text-slate-900 tracking-tight leading-none uppercase">KLEHUB</h1>
              <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest mt-1">
                {role === 'employee' ? 'Management Console' : 'Digital Resource Hub'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 max-w-2xl mx-12">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
            <input 
              type="text" 
              placeholder="Search local records, ISBN, or authors..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-100 rounded-xl py-2.5 pl-11 pr-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/10 focus:border-indigo-600 transition-all text-sm font-medium"
            />
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
             <button 
              onClick={() => setActiveTab('inventory')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${activeTab === 'inventory' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-800'}`}
             >
               INVENTORY
             </button>
             <button 
              onClick={() => setActiveTab('archive')}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${activeTab === 'archive' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-800'}`}
             >
               ARCHIVE
             </button>
          </div>
          <div className="w-px h-6 bg-slate-200" />
          <div className="relative">
            <button 
              onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
              className="flex items-center gap-2 px-3 py-1.5 hover:bg-slate-50 rounded-lg transition-colors group"
            >
              <Languages className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest group-hover:text-slate-900">{currentLang}</span>
            </button>
            
            <AnimatePresence>
              {isLangMenuOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-[60]" 
                    onClick={() => setIsLangMenuOpen(false)}
                  />
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-48 bg-white border border-slate-100 rounded-2xl shadow-xl z-[70] p-2 overflow-hidden"
                  >
                    {[
                      { code: 'EN', label: 'English' },
                      { code: 'HI', label: 'Hindi (हिंदी)' },
                      { code: 'KN', label: 'Kannada (ಕನ್ನಡ)' }
                    ].map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          setCurrentLang(lang.code as any);
                          setIsLangMenuOpen(false);
                        }}
                        className={`w-full text-left px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${currentLang === lang.code ? 'bg-indigo-50 text-indigo-600' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'}`}
                      >
                        {lang.label}
                      </button>
                    ))}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
          <div className="w-px h-6 bg-slate-200" />
          <button 
            onClick={() => setIsProfileOpen(true)}
            className="flex items-center gap-3 group px-3 py-2 rounded-2xl hover:bg-slate-50 transition-all border border-transparent hover:border-slate-100"
          >
             <div className="text-right hidden sm:block">
               <p className="text-sm font-bold text-slate-900 leading-none capitalize">{userInfo.name}</p>
               <p className="text-[10px] text-slate-500 font-bold uppercase mt-1 tracking-widest">{role}</p>
             </div>
             <div className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white shadow-sm flex items-center justify-center font-black text-slate-600 group-hover:border-indigo-600 transition-colors uppercase">
               {userInfo.avatar}
             </div>
          </button>
        </div>
      </header>

      <div className="flex flex-1">
        {/* SIDEBAR */}
        <aside className="w-64 bg-slate-900 text-slate-400 hidden lg:flex flex-col border-r border-slate-800 p-6">
          <div className="flex items-center gap-3 mb-10 px-4">
             <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnu3_NV41wNtPV0D7Ugsvb2W7EYlOaBFUkOg&s" className="w-8 h-8 object-contain" alt="KLEHUB Logo" referrerPolicy="no-referrer" />
             <span className="text-xl font-black text-white tracking-tighter uppercase">KLEHUB</span>
          </div>
          <nav className="space-y-2 flex-1">
             <div 
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white font-bold' : 'hover:bg-slate-800 hover:text-white'}`}
             >
               <Home className="w-5 h-5" /> {t('dashboard')}
             </div>
             <div 
              onClick={() => setActiveTab('inventory')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${activeTab === 'inventory' ? 'bg-indigo-600 text-white font-bold' : 'hover:bg-slate-800 hover:text-white'}`}
             >
               <Database className="w-5 h-5" /> {role === 'employee' ? t('inventory') : t('explore_books')}
             </div>
             <div 
              onClick={() => setActiveTab('archive')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${activeTab === 'archive' ? 'bg-indigo-600 text-white font-bold' : 'hover:bg-slate-800 hover:text-white'}`}
             >
               <Archive className="w-5 h-5" /> {t('archive')}
             </div>
             {role === 'employee' && (
               <div 
                onClick={() => setActiveTab('settings')}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${activeTab === 'settings' ? 'bg-indigo-600 text-white font-bold' : 'hover:bg-slate-800 hover:text-white'}`}
               >
                 <Settings className="w-5 h-5" /> {t('settings')}
               </div>
             )}

          </nav>
          <div className="pt-6 border-t border-slate-800">
             <button 
              onClick={() => {
                setRole('guest');
                setAuthStep('selection');
              }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-all font-bold"
             >
               <LogOut className="w-5 h-5" /> {t('logout')}
             </button>
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto bg-slate-50/50 flex flex-col">
          <div className="flex-1 p-8">
            <div className="max-w-6xl mx-auto">
              {activeTab === 'dashboard' ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-12"
              >
                <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12">
                  <div>
                    <h2 className="text-4xl font-black text-slate-900 uppercase tracking-tight mb-2">{t('systems_overview')}</h2>
                    <p className="text-slate-500 font-medium">{t('real_time_metrics')}</p>
                  </div>
                  <div className="flex gap-3">
                    <button 
                      onClick={() => setActiveTab('inventory')}
                      className="px-6 py-3 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-colors shadow-sm"
                    >
                      {t('scan_catalog')}
                    </button>
                    <button onClick={() => setIsModalOpen(true)} className="px-6 py-3 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100">{t('new_resource')}</button>
                    <button 
                      onClick={() => setActiveTab('archive')}
                      className="px-6 py-3 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-colors shadow-sm"
                    >
                      {t('print_codes')}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                   <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                      <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6">
                        <Book className="w-6 h-6 text-indigo-600" />
                      </div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Catalog</p>
                      <p className="text-3xl font-black text-slate-900">{books.length}</p>
                   </div>
                   <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                      <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center mb-6">
                        <ShieldCheck className="w-6 h-6 text-emerald-600" />
                      </div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Available Now</p>
                      <p className="text-3xl font-black text-emerald-600">{books.filter(b => b.available).length}</p>
                   </div>
                   <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                      <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center mb-6">
                        <User className="w-6 h-6 text-amber-600" />
                      </div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Active Readers</p>
                      <p className="text-3xl font-black text-slate-900">482</p>
                   </div>
                   <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                      <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6">
                        <Database className="w-6 h-6 text-indigo-600" />
                      </div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Data Health</p>
                      <p className="text-3xl font-black text-indigo-600">99%</p>
                   </div>
                </div>

                <div className="grid lg:grid-cols-3 gap-8">
                   <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-8">
                      <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight mb-8">
                        {role === 'employee' ? 'Acquisition Trends' : 'Your Learning Progress'}
                      </h3>
                      <div className="h-64 flex items-end gap-4">
                         {[40, 70, 45, 90, 65, 80, 55].map((val, i) => (
                           <div key={i} className="flex-1 bg-slate-100 rounded-t-xl relative group">
                              <motion.div 
                                initial={{ height: 0 }}
                                animate={{ height: `${val}%` }}
                                className="absolute bottom-0 left-0 right-0 bg-indigo-600 rounded-t-xl transition-all group-hover:bg-indigo-400"
                              />
                           </div>
                         ))}
                      </div>
                      <div className="flex justify-between mt-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                         <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
                      </div>
                   </div>

                   <div className="bg-slate-900 rounded-3xl p-8 text-white">
                      {role === 'employee' ? (
                        <>
                          <h3 className="text-lg font-black uppercase tracking-tight mb-8">System Status</h3>
                          <div className="space-y-6">
                             <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-slate-400">Inventory Sync</span>
                                <span className="text-[10px] font-black px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded-md">OPERATIONAL</span>
                             </div>
                             <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-slate-400">Database Engine</span>
                                <span className="text-[10px] font-black px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded-md">OPERATIONAL</span>
                             </div>
                             <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-slate-400">User Auth API</span>
                                <span className="text-[10px] font-black px-2 py-1 bg-emerald-500/20 text-emerald-400 rounded-md">OPERATIONAL</span>
                             </div>
                          </div>
                          <div className="mt-12 p-6 bg-white/5 rounded-2xl border border-white/10">
                             <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Staff Bulletin</p>
                             <p className="text-xs text-slate-400 leading-relaxed italic">"Next database maintenance scheduled for Friday 22:00 UTC. Ensure all records are committed."</p>
                          </div>
                        </>
                      ) : (
                        <>
                          <h3 className="text-lg font-black uppercase tracking-tight mb-8">Library Alerts</h3>
                          <div className="space-y-6">
                             <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
                                   <Info className="w-5 h-5" />
                                </div>
                                <div>
                                   <p className="text-xs font-bold">Return Reminder</p>
                                   <p className="text-[10px] text-slate-500 font-medium whitespace-nowrap">"Introduction to Algorithms" due in 2 days.</p>
                                </div>
                             </div>
                             <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                                   <Plus className="w-5 h-5" />
                                </div>
                                <div>
                                   <p className="text-xs font-bold">New Arrivals</p>
                                   <p className="text-[10px] text-slate-500 font-medium whitespace-nowrap">3 new Security books added to catalog.</p>
                                </div>
                             </div>
                             <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                                   <LogOut className="w-5 h-5" />
                                </div>
                                <div>
                                   <p className="text-xs font-bold">Reservation Ready</p>
                                   <p className="text-[10px] text-slate-500 font-medium whitespace-nowrap">Pick up "React Design Patterns" at counter B.</p>
                                </div>
                             </div>
                          </div>
                          <div className="mt-12 p-6 bg-indigo-600 rounded-2xl shadow-lg border border-indigo-400">
                             <p className="text-[10px] font-black text-white/60 uppercase tracking-widest mb-2">Student Tip</p>
                             <p className="text-xs text-white leading-relaxed font-bold">"Use the search filter to quickly find journals in the Science section for your thesis."</p>
                          </div>
                        </>
                      )}
                   </div>
                </div>
              </motion.div>
            ) : activeTab === 'inventory' ? (
              <>
                {/* SEARCH & ACTIONS */}
                <div className="flex flex-col md:flex-row gap-6 justify-between items-center mb-12">
                   <div className="relative w-full md:w-96 group">
                     <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
                     <input 
                       type="text" 
                       placeholder="Search library resources..." 
                       value={searchTerm}
                       onChange={(e) => setSearchTerm(e.target.value)}
                       className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 transition-all text-slate-900 font-medium placeholder:text-slate-400"
                     />
                   </div>

                   {role === 'employee' && (
                     <button 
                      onClick={() => setIsModalOpen(true)}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-indigo-200 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
                     >
                       <Plus className="w-5 h-5" /> ADD NEW BOOK
                     </button>
                   )}
                </div>

                {/* STATS STRIP (Theme consistency) */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
                   <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                     <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Total Assets</p>
                     <p className="text-2xl font-black text-slate-900">{books.length}</p>
                   </div>
                   <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                     <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Available</p>
                     <p className="text-2xl font-black text-emerald-600">{books.filter(b => b.available).length}</p>
                   </div>
                   <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                     <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Categories</p>
                     <p className="text-2xl font-black text-indigo-600">{new Set(books.map(b => b.category)).size}</p>
                   </div>
                   <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                     <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Status</p>
                     <p className="text-2xl font-black text-emerald-600">Normal</p>
                   </div>
                </div>

                {/* BOOK GRID */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  <AnimatePresence mode="popLayout">
                    {filteredBooks.map((book, idx) => (
                      <motion.div
                        layout
                        key={book.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        transition={{ delay: idx * 0.05 }}
                        className="group bg-white rounded-3xl border border-slate-200 overflow-hidden hover:border-indigo-300 transition-all hover:shadow-xl hover:shadow-indigo-900/5 flex flex-col"
                      >
                        <div className="relative h-64 bg-slate-50 flex items-center justify-center overflow-hidden">
                           <div className="absolute top-4 right-4 z-10">
                             {role === 'employee' ? (
                               <div className="flex gap-2">
                                 <button onClick={() => openEdit(book)} className="p-2 bg-white/80 backdrop-blur rounded-lg text-slate-600 hover:text-indigo-600 border border-slate-200 transition-colors shadow-sm"><Edit2 className="w-4 h-4" /></button>
                                 <button onClick={() => handleDelete(book.id)} className="p-2 bg-white/80 backdrop-blur rounded-lg text-slate-600 hover:text-red-600 border border-slate-200 transition-colors shadow-sm"><Trash2 className="w-4 h-4" /></button>
                               </div>
                             ) : (
                               <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${book.available ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-red-50 text-red-600 border-red-200'}`}>
                                 {book.available ? 'AVAILABLE' : 'BORROWED'}
                               </span>
                             )}
                           </div>
                           {book.imageUrl ? (
                             <img 
                              src={book.imageUrl} 
                              alt={book.title} 
                              className="w-full h-full object-contain transition-transform duration-700 group-hover:scale-110 p-2"
                              referrerPolicy="no-referrer"
                             />
                           ) : (
                             <Book className="w-16 h-16 text-slate-300 group-hover:text-indigo-500 group-hover:scale-110 transition-all duration-500" />
                           )}
                           
                           {!book.available && book.borrowedBy === 'current-user-123' && (
                             <motion.div 
                               initial={{ opacity: 0 }}
                               animate={{ opacity: 1 }}
                               className="absolute inset-0 bg-indigo-600/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20 cursor-pointer"
                               onClick={() => setCurrentlyReading(book)}
                             >
                               <BookOpen className="w-12 h-12 text-white mb-4 animate-bounce" />
                               <p className="text-[10px] font-black text-white uppercase tracking-[0.2em] mb-4">You have access</p>
                               <span className="bg-white text-indigo-600 px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-xl">
                                 Read Now
                               </span>
                             </motion.div>
                           )}

                           <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                           <div className="absolute bottom-4 left-4">
                             <span className="bg-indigo-600 text-white text-[9px] font-black uppercase px-2 py-1 rounded-md tracking-tighter">{book.category}</span>
                           </div>
                        </div>

                        <div className="p-8 flex-1 flex flex-col">
                          <h3 className="text-xl font-bold text-slate-900 mb-1 leading-tight">{book.title}</h3>
                          <p className="text-xs font-bold text-slate-400 mb-4 tracking-wide uppercase">BY {book.author}</p>
                          <p className="text-slate-500 text-sm leading-relaxed mb-6 line-clamp-3">
                            {book.description}
                          </p>
                          <div className="mt-auto pt-6 border-t border-slate-100 flex items-center justify-between">
                             <button 
                              onClick={() => setViewingBook(book)}
                              className="text-indigo-600 text-sm font-black flex items-center gap-1 hover:translate-x-1 transition-transform uppercase tracking-tighter"
                             >
                               View Details <ChevronRight className="w-4 h-4" />
                             </button>
                             {role === 'student' && (
                               book.available ? (
                                 <button 
                                   onClick={(e) => {
                                     e.stopPropagation();
                                     handleBorrow(book.id);
                                   }}
                                   className="bg-slate-900 text-white text-[10px] font-black py-2 px-4 rounded-lg hover:bg-indigo-600 transition-colors uppercase tracking-widest shadow-lg shadow-slate-200"
                                 >
                                   Borrow
                                 </button>
                               ) : book.borrowedBy === 'current-user-123' ? (
                                 <button 
                                   onClick={(e) => {
                                     e.stopPropagation();
                                     setCurrentlyReading(book);
                                   }}
                                   className="bg-indigo-600 text-white text-[10px] font-black py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors uppercase tracking-widest shadow-lg shadow-indigo-100"
                                 >
                                   Read Now
                                 </button>
                               ) : null
                             )}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>

                {filteredBooks.length === 0 && (
                  <div className="text-center py-32 bg-slate-100/50 rounded-3xl border-2 border-dashed border-slate-200">
                    <Book className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <p className="text-xl text-slate-400 font-bold italic tracking-tight">No resources matched your investigation.</p>
                  </div>
                )}
              </>
            ) : activeTab === 'archive' ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-12">
                  <div>
                    <h2 className="text-4xl font-black text-slate-900 uppercase tracking-tight mb-2">Digital Archive</h2>
                    <p className="text-slate-500 font-medium">Historical records and decommissioned resources.</p>
                  </div>
                </div>

                <div className="bg-white rounded-[40px] border border-slate-200 p-16 flex flex-col items-center text-center">
                   <div className="w-24 h-24 bg-slate-50 rounded-[32px] flex items-center justify-center mb-8 border border-slate-100">
                      <Archive className="w-10 h-10 text-slate-300" />
                   </div>
                   <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight mb-4">Archive Empty</h3>
                   <p className="text-slate-500 font-medium max-w-sm border-b-2 border-indigo-100 pb-2"> No books have been archived yet. All records are currently active in the main inventory system.</p>
                   <button 
                    onClick={() => setActiveTab('inventory')}
                    className="mt-12 text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:underline"
                   >
                     Return to Main Catalog
                   </button>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="max-w-4xl"
              >
                 <div className="mb-12">
                   <h2 className="text-4xl font-black text-slate-900 uppercase tracking-tight mb-2">Internal Settings</h2>
                   <p className="text-slate-500 font-medium">Configure your workstation and library management preferences.</p>
                 </div>

                 <div className="space-y-8">
                    <section className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                       <div className="p-6 border-b border-slate-100 bg-slate-50">
                          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                             <User className="w-4 h-4 text-indigo-600" /> Account Identity
                          </h3>
                       </div>
                       <div className="p-8 grid md:grid-cols-2 gap-8">
                          <div>
                             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Display Name</label>
                             <input type="text" defaultValue={userInfo.name} className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-medium" />
                          </div>
                          <div>
                             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Email Address</label>
                             <input type="email" defaultValue={userInfo.email} className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-medium" />
                          </div>
                       </div>
                    </section>

                    <section className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                       <div className="p-6 border-b border-slate-100 bg-slate-50">
                          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                             <ShieldCheck className="w-4 h-4 text-indigo-600" /> Security & Access
                          </h3>
                       </div>
                       <div className="p-8 space-y-6">
                           <div className="flex items-center justify-between">
                              <div>
                                 <p className="text-sm font-bold text-slate-900">Two-Factor Authentication</p>
                                 <p className="text-xs text-slate-500">Add an extra layer of security to your KLEHUB account.</p>
                              </div>
                              <div className="w-12 h-6 bg-emerald-500 rounded-full relative cursor-pointer shadow-inner">
                                 <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-md" />
                              </div>
                           </div>
                           <div className="flex items-center justify-between opacity-50">
                              <div>
                                 <p className="text-sm font-bold text-slate-900">Biometric Login</p>
                                 <p className="text-xs text-slate-500">Use system hardware for instant management access.</p>
                              </div>
                              <div className="w-12 h-6 bg-slate-200 rounded-full relative cursor-not-allowed">
                                 <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm" />
                              </div>
                           </div>
                       </div>
                    </section>

                    <section className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
                       <div className="p-6 border-b border-slate-100 bg-slate-50">
                          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                             <Mail className="w-4 h-4 text-indigo-600" /> Notifications
                          </h3>
                       </div>
                       <div className="p-8 space-y-6">
                           <div className="flex items-center justify-between">
                              <p className="text-sm font-bold text-slate-900">Overdue Alerts</p>
                              <div className="w-12 h-6 bg-indigo-600 rounded-full relative cursor-pointer shadow-inner">
                                 <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-md" />
                              </div>
                           </div>
                           <div className="flex items-center justify-between">
                              <p className="text-sm font-bold text-slate-900">New Acquisition Updates</p>
                              <div className="w-12 h-6 bg-indigo-600 rounded-full relative cursor-pointer shadow-inner">
                                 <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-md" />
                              </div>
                           </div>
                       </div>
                    </section>

                    <div className="flex justify-end gap-4">
                       <button onClick={() => setActiveTab('inventory')} className="px-8 py-4 text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-slate-900 transition-colors">Discard Changes</button>
                       <button className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-slate-200 hover:bg-indigo-600 transition-all">Save Preferences</button>
                    </div>
                 </div>
              </motion.div>
            )}
          </div>
        </div>
          
        <footer className="border-t border-slate-200 bg-white p-8">
            <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
               <div className="flex items-center gap-3">
                  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnu3_NV41wNtPV0D7Ugsvb2W7EYlOaBFUkOg&s" className="w-5 h-5 object-contain" alt="KLEHUB Logo" referrerPolicy="no-referrer" />
                  <span className="text-sm font-black text-slate-900 uppercase tracking-tighter">KLEHUB DIGITAL PLATFORM</span>
               </div>
               <div className="flex gap-8 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  <a href="#" className="hover:text-indigo-600 transition-colors">Digital Guidelines</a>
                  <a href="#" className="hover:text-indigo-600 transition-colors">Privacy Policy</a>
                  <a href="#" className="hover:text-indigo-600 transition-colors">System Support</a>
                  <a href="#" className="hover:text-indigo-600 transition-colors">Contact Admin</a>
               </div>
               <p className="text-[10px] font-bold text-slate-400">© 2026 KLE Technological University. Built for Excellence.</p>
            </div>
          </footer>
        </main>
      </div>

      {/* CRUD MODAL */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              onClick={() => { setIsModalOpen(false); resetForm(); }}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden border border-slate-200"
            >
              <div className="p-8 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight">
                  {editingBook ? 'Edit Resource' : 'Add New Asset'}
                </h2>
                <button onClick={() => { setIsModalOpen(false); resetForm(); }} className="text-slate-400 hover:text-slate-800 font-black">CLOSE</button>
              </div>
              <form onSubmit={handleAddOrUpdate} className="p-8 space-y-6">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Book Title</label>
                  <input 
                    type="text" 
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-medium"
                    placeholder="E.g. Advanced Quantum Physics"
                  />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Author</label>
                    <input 
                      type="text" 
                      value={newAuthor}
                      onChange={(e) => setNewAuthor(e.target.value)}
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-medium"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Category</label>
                    <select 
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-medium"
                    >
                      <option>Software</option>
                      <option>Data</option>
                      <option>Science</option>
                      <option>Physics</option>
                      <option>Mathematics</option>
                      <option>History</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Cover Image URL</label>
                  <input 
                    type="url" 
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-medium"
                    placeholder="https://images.unsplash.com/..."
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Description</label>
                  <textarea 
                    rows={4}
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-indigo-600/20 focus:border-indigo-600 text-slate-900 font-medium"
                  />
                </div>
                <button 
                  type="submit" 
                  className="w-full bg-slate-900 hover:bg-indigo-600 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-slate-200 uppercase tracking-widest"
                >
                  {editingBook ? 'Save Changes' : 'Initialize Asset'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* VIEW DETAILS MODAL */}
      <AnimatePresence>
        {currentlyReading && (() => {
          const tBook = getTranslatedBook(currentlyReading);
          return (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-white flex flex-col"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-10">
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setCurrentlyReading(null)}
                    className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                  >
                    <ArrowLeft className="w-6 h-6 text-slate-900" />
                  </button>
                  <div>
                    <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight leading-none">{tBook.title}</h2>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Reader View • Section Alpha</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest">
                    <ShieldCheck className="w-4 h-4" /> Secure Access
                  </div>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto bg-slate-50 py-20 px-8">
                <div className="max-w-3xl mx-auto bg-white p-12 md:p-20 rounded-[48px] shadow-2xl shadow-indigo-900/5 min-h-screen">
                  <div className="font-mono text-[10px] text-slate-300 mb-12 flex justify-between uppercase tracking-[0.2em] border-b border-slate-50 pb-6">
                    <span>DOC_ID: {tBook.id}</span>
                    <span>PAGE: 01-14</span>
                    <span>INSTITUTION: KLE TECH</span>
                  </div>
                  
                  <div className="prose prose-slate max-w-none">
                    <pre className="whitespace-pre-wrap font-sans text-lg text-slate-700 leading-[1.8] font-medium">
                      {tBook.fullContent || (currentLang === 'HI' ? HI_SAMPLE_CONTENT : currentLang === 'KN' ? KN_SAMPLE_CONTENT : SAMPLE_CONTENT)}
                    </pre>
                  </div>
                  
                  <div className="mt-20 pt-12 border-t border-slate-100 flex justify-center">
                    <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.4em]">End of Digital record</p>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })()}

        {viewingBook && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              onClick={() => setViewingBook(null)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden border border-slate-200"
            >
              <div className="flex flex-col md:flex-row h-full">
                <div className="md:w-1/2 bg-slate-50 flex items-center justify-center p-8 border-b md:border-b-0 md:border-r border-slate-100">
                  {viewingBook.imageUrl ? (
                    <img 
                      src={viewingBook.imageUrl} 
                      alt={viewingBook.title} 
                      className="max-w-full max-h-[300px] object-contain rounded-xl shadow-lg shadow-indigo-900/10"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <Book className="w-24 h-24 text-slate-300" />
                  )}
                </div>
                <div className="p-8 md:w-1/2 flex flex-col">
                    <div className="mb-6">
                      <span className="bg-indigo-600 text-white text-[9px] font-black uppercase px-2 py-1 rounded-md tracking-tighter mb-2 inline-block">
                        {getTranslatedBook(viewingBook).category}
                      </span>
                      <h2 className="text-3xl font-black text-slate-900 leading-tight mb-1">{getTranslatedBook(viewingBook).title}</h2>
                      <p className="text-xs font-bold text-slate-400 tracking-widest uppercase mb-4">Authored by {viewingBook.author}</p>
                      <div className="h-1 w-12 bg-indigo-600 rounded-full mb-6" />
                      <p className="text-slate-500 text-sm leading-relaxed mb-8">
                        {getTranslatedBook(viewingBook).description}
                      </p>
                    </div>
                  
                  <div className="mt-auto flex items-center justify-between gap-4">
                    <div className="flex-1">
                      {role === 'student' ? (
                        viewingBook.available ? (
                          <button 
                            onClick={() => {
                              handleBorrow(viewingBook.id);
                              setViewingBook(null);
                            }}
                            className="w-full bg-slate-900 hover:bg-indigo-600 text-white font-black py-4 rounded-xl transition-all shadow-xl shadow-slate-200 uppercase tracking-widest text-[10px]"
                          >
                            {t('confirm_borrow')}
                          </button>
                        ) : viewingBook.borrowedBy === 'current-user-123' ? (
                          <button 
                            onClick={() => {
                              setCurrentlyReading(viewingBook);
                              setViewingBook(null);
                            }}
                            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black py-4 rounded-xl transition-all shadow-xl shadow-indigo-100 uppercase tracking-widest text-[10px]"
                          >
                            {t('open_reader')}
                          </button>
                        ) : (
                          <button 
                            disabled
                            className="w-full bg-slate-100 text-slate-400 font-black py-4 rounded-xl cursor-not-allowed uppercase tracking-widest text-[10px]"
                          >
                            {t('currently_unavailable')}
                          </button>
                        )
                      ) : (
                        <button 
                          onClick={() => setViewingBook(null)}
                          className="w-full bg-slate-900 hover:bg-slate-800 text-white font-black py-4 rounded-xl transition-all uppercase tracking-widest text-[10px]"
                        >
                          Close Details
                        </button>
                      )}
                    </div>
                    {role === 'employee' && (
                        <button 
                          onClick={() => {
                            if (viewingBook) handleDelete(viewingBook.id);
                          }}
                          className="text-red-500 text-[9px] font-black uppercase hover:text-red-700 transition-colors mt-1 flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" /> Remove Resource
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      {/* PROFILE MODAL */}
      <AnimatePresence>
        {isProfileOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              onClick={() => setIsProfileOpen(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-slate-200"
            >
               <div className="relative h-32 bg-indigo-600">
                  <div className="absolute -bottom-12 left-8 w-24 h-24 rounded-3xl bg-white p-1 shadow-xl">
                    <div className="w-full h-full rounded-2xl bg-slate-100 flex items-center justify-center font-black text-3xl text-indigo-600 uppercase">
                      {userInfo.avatar}
                    </div>
                  </div>
                  <button onClick={() => setIsProfileOpen(false)} className="absolute top-6 right-6 text-white/80 hover:text-white font-black">X</button>
               </div>
               
               <div className="pt-16 p-8">
                  <div className="mb-8">
                    <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight leading-none mb-2">{userInfo.name}</h2>
                    <p className="text-xs font-bold text-indigo-600 uppercase tracking-widest">{userInfo.dept}</p>
                  </div>

                  <div className="space-y-4">
                     <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Identification ID</p>
                        <p className="text-sm font-bold text-slate-900">{userInfo.id}</p>
                     </div>
                     <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Official Email</p>
                        <p className="text-sm font-bold text-slate-900">{userInfo.email}</p>
                     </div>
                     <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Account Standing</p>
                        <div className="flex items-center gap-2 mt-1">
                           <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-sm" />
                           <p className="text-xs font-bold text-emerald-600">Active • Verified Account</p>
                        </div>
                     </div>
                     <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Joined</p>
                          <p className="text-sm font-bold text-slate-900">Aug 2023</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Books Borrowed</p>
                          <p className="text-sm font-bold text-slate-900">12 Total</p>
                        </div>
                     </div>
                  </div>

                  <div className="mt-8 flex gap-3">
                     <button className="flex-1 bg-slate-900 text-white font-black py-4 rounded-2xl text-[10px] tracking-widest uppercase hover:bg-slate-800 transition-all">Download Tag</button>
                     <button 
                      onClick={() => {
                        setRole('guest');
                        setIsProfileOpen(false);
                      }}
                      className="flex-1 bg-red-50 text-red-600 border border-red-100 font-black py-4 rounded-2xl text-[10px] tracking-widest uppercase hover:bg-red-100 transition-all"
                     >
                       Logout
                      </button>
                  </div>
               </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}


